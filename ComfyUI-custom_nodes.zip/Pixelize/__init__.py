from .nodes import Img2PicEnergyPixelize

NODE_CLASS_MAPPINGS = {
    "Img2PicEnergyPixelize": Img2PicEnergyPixelize,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "Img2PicEnergyPixelize": "Img2Pic - 能量网格像素化",
}
